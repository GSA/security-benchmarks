GSA ISE Windows Server 2008 R2 GPO


ADMs used:

<MSS-legacy> from...
https://blogs.technet.microsoft.com/secguide/2016/10/02/the-mss-settings/

<Win7-2008R2-admx.msi> which includes <ShapeCollector.admx/adml> from...
https://www.microsoft.com/en-us/download/confirmation.aspx?id=6243

<CIS_Microsoft_Windows_Server_2008_R2_Remediation_Kit.zip> which includes <Disable-IPv6-Components-KB929852.adm> from...
https://workbench.cisecurity.org/files/1236

=================================================

Settings not configured:
2.2.17 - User List
2.2.21 - User List
18.9.30.4 - doesn't map over (File Explorer)
18.9.69.3.1 - doesn't map over (Windows Defender - MAPS)


RLR - 2:13 PM 5/19/2017

{EOD}